<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title>Doug's Site</title>
    </head>
    <body>

    <h1>Doug's Site</h1>

    <p> <?php  echo "This is some text"; ?> </p>

    <p> <?= "This is some text"; ?> </p>

    </body>
</html>